import express from 'express';
import * as db from './util/database.js';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());
const PORT = 5050;

function getTodayDate() {
  const d = new Date();
  return d.toISOString().split('T')[0];
}

app.get('/blogs', (req, res) => {
  try {
    const blogs = db.getBlogs();
    res.status(200).json(blogs);
  } catch (err) {
    res.status(500).json({ message: 'Database error: ' + err.message });
  }
});

app.get('/blogs/:id', (req, res) => {
  try {
    const blog = db.getBlog(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    res.status(200).json(blog);
  } catch (err) {
    res.status(500).json({ message: 'Database error: ' + err.message });
  }
});

app.post('/blogs', (req, res) => {
  try {
    const { author, title, category, content } = req.body;

    if (
      !author || !author.trim() || author.startsWith(' ') ||
      !title || !title.trim() ||
      !category || !category.trim() ||
      !content || !content.trim()
    ) {
      return res.status(400).json({ message: 'Invalid or empty fields' });
    }

    const today = getTodayDate();

    const savedBlog = db.saveBlog(author.trim(), title.trim(), category.trim(), content.trim(), today);

    if (savedBlog.lastInsertRowid === undefined) {
      return res.status(500).json({ message: 'Save failed' });
    }

    res.status(201).json({ 
      id: savedBlog.lastInsertRowid,
      author: author.trim(),
      title: title.trim(),
      category: category.trim(),
      content: content.trim(),
      creation: today,
      modification: null
    });
  } catch (err) {
    res.status(500).json({ message: 'Database error: ' + err.message });
  }
});


app.put('/blogs/:id', (req, res) => {
  try {
    const { author, title, category, content } = req.body;

    if (
      !author || !author.trim() || author.startsWith(' ') ||
      !title || !title.trim() ||
      !category || !category.trim() ||
      !content || !content.trim()
    ) {
      return res.status(400).json({ message: 'Invalid or empty fields' });
    }

    const id = +req.params.id;
    const modification = getTodayDate();

    const updatedBlog = db.updateBlog(id, author.trim(), title.trim(), category.trim(), content.trim(), modification);

    if (updatedBlog.changes !== 1) {
      return res.status(404).json({ message: 'Blog not found or update failed' });
    }

    const blog = db.getBlog(id);

    res.status(200).json(blog);
  } catch (err) {
    res.status(500).json({ message: 'Database error: ' + err.message });
  }
});


app.delete('/blogs/:id', (req, res) => {
  try {
    const deletedBlog = db.deleteBlog(req.params.id);
    if (deletedBlog.changes !== 1) {
      return res.status(404).json({ message: 'Blog not found or delete failed' });
    }
    res.status(200).json({ message: 'Delete successful' });
  } catch (err) {
    res.status(500).json({ message: 'Database error: ' + err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
