import Database from 'better-sqlite3';

const db = new Database('./data/database.sqlite');

db.prepare(`CREATE TABLE IF NOT EXISTS blogs (id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT, title TEXT, category TEXT, content TEXT, creation DATE, modification DATE)`).run();

export const getBlogs = () => db.prepare('SELECT * FROM blogs').all();
export const getBlog = (id) => db.prepare('SELECT * FROM blogs WHERE id = ?').get(id);
export const saveBlog = (author, title, category, content, creation) => db.prepare(`INSERT INTO blogs (author, title, category, content, creation) VALUES (?, ?, ?, ?, ?)`).run(author, title, category, content, creation);
export const updateBlog = (id, author, title, category, content, modification) => db.prepare(`UPDATE blogs SET author = ?, title = ?, category = ?, content = ?, modification = ? WHERE id = ?`).run(author, title, category, content, modification, id);
export const deleteBlog = (id) => db.prepare('DELETE FROM blogs WHERE id = ?').run(id);

const blogs = [
  {author: 'Anna', title: 'Kacsa', category: 'Állat', content: 'Imádom a kacsákat.', creation: '2023-01-25'},
  {author: 'Anna', title: 'Liba', category: 'Állat', content: 'A libák kicsit morcosabbak.', creation: '2025-01-12'},
  {author: 'Béla', title: 'JavaScript kezdőknek', category: 'Programozás', content: 'Tanuljuk meg a JS-t.', creation: '2025-05-19'},
  {author: 'Béla', title: 'Express API', category: 'Programozás', content: 'Express egyszerű és gyors.', creation: '2025-05-15'},
  {author: 'Csilla', title: 'Gasztronómia', category: 'Étel', content: 'A főzés művészet.', creation: '2025-05-10'},
  {author: 'Csilla', title: 'Tészták világa', category: 'Étel', content: 'A spagetti a kedvencem.', creation: '2025-04-19'}
];

// for (const blog of blogs) saveBlog(blog.author, blog.title, blog.category, blog.content, blog.creation, blog.modification);